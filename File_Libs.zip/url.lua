-- Placeholder for url.lua library
local url = {}
return url