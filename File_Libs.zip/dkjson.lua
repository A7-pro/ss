-- Placeholder for dkjson.lua library
local dkjson = {}
return dkjson