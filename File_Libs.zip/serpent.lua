-- Placeholder for serpent.lua library
local serpent = {}
return serpent