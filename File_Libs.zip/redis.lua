-- Placeholder for redis.lua library
local redis = {}
return redis