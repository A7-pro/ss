-- Placeholder for JSON.lua library
local JSON = {}
return JSON